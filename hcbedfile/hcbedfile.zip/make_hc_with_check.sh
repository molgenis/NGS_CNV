if [ $(bc <<< "${popOverlapPercentage}>=${popOverlapThreshold}") -eq 1 ]
then
	echo "[...CREATE THE HIGH CONFIDENT BED FILE...]"
	cat "${hcdir}"HC_populatie1 "${hcdir}"HC_populatie2 | cut -f1,2,3 | sort | uniq -c | awk '($1==2)' | sed 's/ \+/\t/g'  | cut -f 3,4,5 | sed 's/X/999999999/g'| sed 's/Y/9999999999/g' | sort -nk1 -nk2 | sed 's/9999999999/Y/g' | sed 's/999999999/X/g' > "${hcdir}"HC_target.bed
elif [ $(bc <<< "${popOverlapPercentage}>=${popOverlapLooseThreshold}") -eq 1 ]
then
	echo "Population overlap was lower than 99% buyt higher than 98%, therefore we will still make the High Confident BED file"
	echo "[...CREATE THE HIGH CONFIDENT BED FILE...]"
	cat "${hcdir}"HC_populatie1 "${hcdir}"HC_populatie2 | cut -f1,2,3 | sort | uniq -c | awk '($1==2)' | sed 's/ \+/\t/g'  | cut -f 3,4,5 | sed 's/X/999999999/g'| sed 's/Y/9999999999/g' | sort -nk1 -nk2 | sed 's/9999999999/Y/g' | sed 's/999999999/X/g' > "${hcdir}"HC_target.bed
else
	echo "Population overlap too small to properly make a High Confident BED file :("
fi
